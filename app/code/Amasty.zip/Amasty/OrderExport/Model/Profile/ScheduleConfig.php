<?php
/**
 * @author Amasty Team
 * @copyright Copyright (c) 2020 Amasty (https://www.amasty.com)
 * @package Amasty_OrderExport
 */


namespace Amasty\OrderExport\Model\Profile;

class ScheduleConfig
{
    const DATAPROVIDER_TYPE = 'basic';
}
